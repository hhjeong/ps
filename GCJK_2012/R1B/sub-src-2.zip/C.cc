#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <cstring>
#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>
#include <algorithm>
using namespace std;

typedef pair<int,int> ii;
typedef long long ll;

int N, M, K;
char board[50][50][50];
int ngroup = 0;
int group[50][50][50];

void dfs( int f, int i, int j ) {
    if( group[f][i][j] != -1 ) return;
    if( board[f][i][j] != '.' ) return;
    //fprintf( stderr, "DFS : %d %d %d %d\n", f, i, j, ngroup);
    group[f][i][j] = ngroup;
    if( i >= 1 ) dfs( f, i-1, j );
    if( i < N-1 ) dfs( f, i+1, j );
    if( j >= 1 ) dfs( f, i, j-1 );
    if( j < M-1 ) dfs( f, i, j+1 );
}

vector< vector<int> > G;
vector<int> cache[2];
vector< bool > visited;

int solve( int where, int parent, int used ) {
    // cerr << where << " " << parent << endl;
    visited[where] = true;
    bool ischild = true;
    int &ret = cache[used][where];
    if( ret != -1 ) return ret;
    ret = 0;

    // 안쓸때 
    int suma = 0;
    for( int i = 0 ; i < G[where].size() ; ++i ) {
        int to = G[where][i];
        if( to == parent ) continue;
        ischild = false;
        suma += solve( to, where, 0 );
    }
    ret = max( ret, suma );
    if( !used ) {
        int sumb = 1;
        for( int i = 0 ; i < G[where].size() ; ++i ) {
            int to = G[where][i];
            if( to == parent ) continue;
            ischild = false;
            sumb += solve( to, where, 1 );
        }
        ret = max( ret, sumb );
    }


    if( ischild ) {
        if( !used ) return 1;
        else return 0;
    }

    return ret;
}

int main() {
    clock_t start_time = clock();
    //freopen("C.in","r",stdin);

    int ncase;
    scanf("%d", &ncase); 

    for( int caseno = 1 ; caseno <= ncase ; ++caseno ) {
        cin >> N >> M >> K;
        for(int k = 0 ; k < K ; ++k ) {
            for( int i = 0 ; i < N ; ++i ) {
                    cin >> board[k][i];
            }
        }

        memset( group, -1, sizeof group );
        ngroup = 0;
        for( int f = 0 ; f < K ; ++f ) for( int i = 0 ; i < N ; ++i ) for( int j = 0 ; j < M ; ++j ) if( board[f][i][j] == '.' && group[f][i][j] == -1 ) {
            dfs( f, i ,j );
            ngroup++;
            //fprintf( stderr, "%d %d %d\n", f, i, j );
        }

        set< ii > edges;
        G.clear();
        G.resize( ngroup, vector<int>() );
        for( int f = 0 ; f < K-1 ; ++f ) {
            for( int i = 0 ; i < N ; ++i ) for( int j = 0 ; j < M ; ++j ) if( board[f][i][j] == '.' && board[f+1][i][j] == '.' ) {
                int here = group[f][i][j];
                int there = group[f+1][i][j];
                // cerr << here << " " << there << endl;
                if( edges.find( ii(here,there) ) != edges.end() ) continue;
                edges.insert(ii(here,there));
                edges.insert(ii(there,here));
                G[here].push_back( there );
                G[there].push_back( here );
            }
        }

        cache[0].clear();
        cache[0].resize( ngroup, -1 );
        cache[1].clear();
        cache[1].resize( ngroup, -1 );

        visited.clear();
        visited.resize( ngroup, 0 );

        int ret = 0;
        for( int i = 0 ; i < ngroup ; ++i ) {
            if( !visited[i] ) {
                // cerr << i << endl;
                ret += solve( i, -1, 0 );
            }
        }
        /*
        for( int i = 0 ; i < ngroup ; ++i ) {
            cerr << i << ": ";
            for( int j = 0 ; j < G[i].size() ; ++j ) cerr << G[i][j] << " ";
            cerr << endl;
        }*/

        printf("Case #%d: ", caseno);
        cout << ret << endl;
		fprintf(stderr,"%d/%d\n", caseno, ncase);
    }
    fprintf(stderr,"Elapsed time : %.3fsec\n", (double)(clock()-start_time)/CLOCKS_PER_SEC);    
}
